#!/bin/sh

sh install.sh
open http://127.0.0.1:8000
