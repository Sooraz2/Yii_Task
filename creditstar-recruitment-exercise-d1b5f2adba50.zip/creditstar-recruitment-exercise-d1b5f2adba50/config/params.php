<?php

return [
    'adminEmail' => 'admin@example.com',
    'senderEmail' => 'tester@example.com',
    'senderName' => 'tester',
];
