<?php

return [
    'class' => \yii\db\Connection::class,
    'dsn' => 'pgsql:host=db;dbname=example',
    'username' => 'example',
    'password' => 'example',
    'charset' => 'utf8'
];
